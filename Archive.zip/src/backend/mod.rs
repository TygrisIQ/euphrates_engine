/// ## contains init methods and handlers for opengl objects and shaders
///
pub mod opengl;
/// ## glfw window abstraction, event handlers and context creation, I may replace glfw with glutin later or have them both
/// as window backends
pub mod window;
